let count = 0;
while (count < 3) {
    count = count + 1;
}
